Download and goto the project dir, then execute the following cmds.
## npm install
## npm start